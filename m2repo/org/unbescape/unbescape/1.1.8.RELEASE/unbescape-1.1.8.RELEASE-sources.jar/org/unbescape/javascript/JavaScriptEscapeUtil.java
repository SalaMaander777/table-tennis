/*
 * =============================================================================
 * 
 *   Copyright (c) 2014-2026 Unbescape (https://www.unbescape.org)
 * 
 *   Licensed under the Apache License, Version 2.0 (the "License");
 *   you may not use this file except in compliance with the License.
 *   You may obtain a copy of the License at
 * 
 *       http://www.apache.org/licenses/LICENSE-2.0
 * 
 *   Unless required by applicable law or agreed to in writing, software
 *   distributed under the License is distributed on an "AS IS" BASIS,
 *   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *   See the License for the specific language governing permissions and
 *   limitations under the License.
 * 
 * =============================================================================
 */
package org.unbescape.javascript;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.Arrays;

/**
 * <p>
 *   Internal class in charge of performing the real escape/unescape operations.
 * </p>
 *
 * @author Daniel Fern&aacute;ndez
 *
 * @since 1.0.0
 *
 */
final class JavaScriptEscapeUtil {



    /*
     * JAVASCRIPT ESCAPE/UNESCAPE OPERATIONS
     * -------------------------------------
     *
     *   See: http://www.ecmascript.org/docs.php
     *        http://mathiasbynens.be/notes/javascript-escapes
     *
     *   (Note that, in the following examples, and in order to avoid escape problems during the compilation
     *    of this class, the backslash symbol is replaced by '%')
     *
     *   - SINGLE ESCAPE CHARACTERS (SECs):
     *        U+0000 -> %0
     *        U+0008 -> %b
     *        U+0009 -> %t
     *        U+000A -> %n
     *        U+000B -> %v  [NOT USED IN ESCAPE - Not supported by Internet Explorer < 9]
     *        U+000C -> %f
     *        U+000D -> %r
     *        U+0022 -> %"
     *        U+0027 -> %'
     *        U+005C -> %%
     *        U+002F -> %/  [ONLY USED WHEN / APPEARS IN </, IN ORDER TO AVOID ISSUES INSIDE <script> TAGS]
     *   - HEXADECIMAL ESCAPE [XHEXA] (only for characters <= U+00FF): %x??
     *   - UNICODE ESCAPE [UHEXA] (also hexadecimal)
     *        Characters <= U+FFFF: %u????
     *        Characters > U+FFFF : %u????%u???? (surrogate character pair)
     *                              %u{?*} [NOT USED - Possible syntax for ECMAScript 6]
     *   - OCTAL ESCAPE: %377 [NOT USED IN ESCAPE - Deprecated in ECMAScript v5]
     *   - GENERAL ESCAPE: %* -> * ('%a' -> 'a')
     *                     (except the [%,%n] sequence, which is not an escape sequence but a line continuation)
     *
     *   - ESCAPED LINE TERMINATORS (LF, CR, CR LF, U+2028, U+2029): These are Line Continuators, allowed in
     *        ECMAScript 2015, and are ignored in output.
     *
     */



    /*
     * Prefixes defined for use in escape and unescape operations
     */
    private static final char ESCAPE_PREFIX = '\\';
    private static final char ESCAPE_XHEXA_PREFIX2 = 'x';
    private static final char ESCAPE_UHEXA_PREFIX2 = 'u';
    private static final char[] ESCAPE_XHEXA_PREFIX = "\\x".toCharArray();
    private static final char[] ESCAPE_UHEXA_PREFIX = "\\u".toCharArray();

    /*
     * Small utility char array for hexadecimal conversion.
     */
    private static char[] HEXA_CHARS_UPPER = "0123456789ABCDEF".toCharArray();


    /*
     * Structures for holding the Single Escape Characters
     */
    private static int SEC_CHARS_LEN = '{' + 1; // 0x7B + 1 = 0x7C
    private static char SEC_CHARS_NO_SEC = '*';
    private static char[] SEC_CHARS;

    /*
     * Structured for holding the 'escape level' assigned to chars (not codepoints) up to ESCAPE_LEVELS_LEN.
     * - The last position of the ESCAPE_LEVELS array will be used for determining the level of all
     *   codepoints >= (ESCAPE_LEVELS_LEN - 1)
     */
    private static final char ESCAPE_LEVELS_LEN = 0x9f + 2; // Last relevant char to be indexed is 0x9f
    private static final byte[] ESCAPE_LEVELS;



    static {

        /*
         * Initialize Single Escape Characters
         */
        SEC_CHARS = new char[SEC_CHARS_LEN];
        Arrays.fill(SEC_CHARS,SEC_CHARS_NO_SEC);
        SEC_CHARS[0x00] = '0';
        SEC_CHARS[0x08] = 'b';
        SEC_CHARS[0x09] = 't';
        SEC_CHARS[0x0A] = 'n';
        SEC_CHARS[0x0C] = 'f';
        SEC_CHARS[0x0D] = 'r';
        SEC_CHARS[0x22] = '"';
        SEC_CHARS[0x27] = '\'';
        SEC_CHARS[0x5C] = '\\';
        // slash (solidus) character: will only be escaped if in '</'
        SEC_CHARS[0x2F] = '/';
        // dollar sign: will only be escaped if followed by '{' or at the end of the text
        SEC_CHARS[0x24] = '$';
        // grave accent (backtick): always escaped
        SEC_CHARS[0x60] = '`';
        // opening curly bracket: will only be escaped if at the beginning of the text
        SEC_CHARS[0x7B] = '{';



        /*
         * Initialization of escape levels.
         * Defined levels :
         *
         *    - Level 1 : Basic escape set
         *    - Level 2 : Basic escape set plus all non-ASCII
         *    - Level 3 : All non-alphanumeric characters
         *    - Level 4 : All characters
         *
         */
        ESCAPE_LEVELS = new byte[ESCAPE_LEVELS_LEN];

        /*
         * Everything is level 3 unless contrary indication.
         */
        Arrays.fill(ESCAPE_LEVELS, (byte)3);

        /*
         * Everything non-ASCII is level 2 unless contrary indication.
         */
        for (char c = 0x80; c < ESCAPE_LEVELS_LEN; c++) {
            ESCAPE_LEVELS[c] = 2;
        }

        /*
         * Alphanumeric characters are level 4.
         */
        for (char c = 'A'; c <= 'Z'; c++) {
            ESCAPE_LEVELS[c] = 4;
        }
        for (char c = 'a'; c <= 'z'; c++) {
            ESCAPE_LEVELS[c] = 4;
        }
        for (char c = '0'; c <= '9'; c++) {
            ESCAPE_LEVELS[c] = 4;
        }

        /*
         * Simple Escape Character will be level 1 (always escaped)
         */
        ESCAPE_LEVELS[0x00] = 1;
        ESCAPE_LEVELS[0x08] = 1;
        ESCAPE_LEVELS[0x09] = 1;
        ESCAPE_LEVELS[0x0A] = 1;
        ESCAPE_LEVELS[0x0C] = 1;
        ESCAPE_LEVELS[0x0D] = 1;
        ESCAPE_LEVELS[0x22] = 1;
        ESCAPE_LEVELS[0x27] = 1;
        ESCAPE_LEVELS[0x5C] = 1;
        // slash (solidus) character: will only be escaped if in '</', but we signal it as level 1 anyway
        ESCAPE_LEVELS[0x2F] = 1;

        /*
         * Grave accent (backtick) will be level 1 (always escaped). Dollar sign and opening curly bracket will only
         * be escaped in specific positions (see escape methods), but we signal them as level 1 anyway. All three are
         * needed for escaped text to be placed inside template literals.
         */
        ESCAPE_LEVELS[0x60] = 1;
        ESCAPE_LEVELS[0x24] = 1;
        ESCAPE_LEVELS[0x7B] = 1;

        /*
         * Ampersand (&) will be level 1 (always escaped) in order to protect from code injection in XHTML
         */
        ESCAPE_LEVELS[0x26] = 1;

        /*
         * Less-than (<) and greater-than (>) will be level 1 (always escaped), so that neither appears in escaped text
         */
        ESCAPE_LEVELS[0x3C] = 1;
        ESCAPE_LEVELS[0x3E] = 1;

        /*
         * JavaScript defines two ranges of non-displayable, control characters (some of which are already part of the
         * Single Escape Characters list): U+0001 to U+001F and U+007F to U+009F.
         */
        for (char c = 0x01; c <= 0x1F; c++) {
            ESCAPE_LEVELS[c] = 1;
        }
        for (char c = 0x7F; c <= 0x9F; c++) {
            ESCAPE_LEVELS[c] = 1;
        }

    }



    private JavaScriptEscapeUtil() {
        super();
    }




    static char[] toXHexa(final int codepoint) {
        final char[] result = new char[2];
        result[1] = HEXA_CHARS_UPPER[codepoint % 0x10];
        result[0] = HEXA_CHARS_UPPER[(codepoint >>> 4) % 0x10];
        return result;
    }


    static char[] toUHexa(final int codepoint) {
        final char[] result = new char[4];
        result[3] = HEXA_CHARS_UPPER[codepoint % 0x10];
        result[2] = HEXA_CHARS_UPPER[(codepoint >>> 4) % 0x10];
        result[1] = HEXA_CHARS_UPPER[(codepoint >>> 8) % 0x10];
        result[0] = HEXA_CHARS_UPPER[(codepoint >>> 12) % 0x10];
        return result;
    }



    private static boolean isDigit(final int c) {
        return c >= '0' && c <= '9';
    }




    /*
     * Perform an escape operation, based on String, according to the specified level and type.
     */
    static String escape(final String text,
                         final JavaScriptEscapeType escapeType, final JavaScriptEscapeLevel escapeLevel) {

        if (text == null) {
            return null;
        }

        final int level = escapeLevel.getEscapeLevel();
        final boolean useSECs = escapeType.getUseSECs();
        final boolean useXHexa = escapeType.getUseXHexa();

        StringBuilder strBuilder = null;

        final int offset = 0;
        final int max = text.length();

        int readOffset = offset;

        for (int i = offset; i < max; i++) {

            final int codepoint = Character.codePointAt(text, i);


            /*
             * Shortcut: most characters will be ASCII/Alphanumeric, and we won't need to do anything at
             * all for them
             */
            if (codepoint <= (ESCAPE_LEVELS_LEN - 2) && level < ESCAPE_LEVELS[codepoint]) {
                continue;
            }

            /*
             * Check whether the character is a slash (solidus). In such case, only escape if it
             * appears after a '<' ('</') or level >= 3 (non alphanumeric)
             */
            if (codepoint == '/' && level < 3 && (i == 0 || text.charAt(i - 1) != '<')) {
                continue;
            }

            /*
             * Check whether the character is a dollar sign. In such case, only escape if it is followed by '{' (which
             * would start a substitution in a template literal), if it is the last char (as code right after the
             * escaped text might start with '{'), or if level >= 3 (non alphanumeric)
             */
            if (codepoint == '$' && level < 3 && (i + 1) < max && text.charAt(i + 1) != '{') {
                continue;
            }

            /*
             * Check whether the character is an opening curly bracket. In such case, only escape if it is the first
             * char (as code right before the escaped text might end with '$'), or if level >= 3 (non alphanumeric)
             */
            if (codepoint == '{' && level < 3 && i > offset) {
                continue;
            }

            /*
             * Shortcut: we might not want to escape non-ASCII chars at all either.
             * We also check we are not dealing with U+2028 or U+2029, which the JavaScript spec considers
             * LineTerminators and therefore should be escaped always.
             */
            if (codepoint > (ESCAPE_LEVELS_LEN - 2) && level < ESCAPE_LEVELS[ESCAPE_LEVELS_LEN - 1] &&
                    codepoint != '\u2028' && codepoint != '\u2029') {

                if (Character.charCount(codepoint) > 1) {
                    // This is to compensate that we are actually escaping two char[] positions with a single codepoint.
                    i++;
                }

                continue;

            }


            /*
             * At this point we know for sure we will need some kind of escape, so we
             * can increase the offset and initialize the string builder if needed, along with
             * copying to it all the contents pending up to this point.
             */

            if (strBuilder == null) {
                strBuilder = new StringBuilder(max + 20);
            }

            if (i - readOffset > 0) {
                strBuilder.append(text, readOffset, i);
            }

            if (Character.charCount(codepoint) > 1) {
                // This is to compensate that we are actually reading two char[] positions with a single codepoint.
                i++;
            }

            readOffset = i + 1;


            /*
             * -----------------------------------------------------------------------------------------
             *
             * Perform the real escape, attending the different combinations of SECs, XHEXA and UHEXA
             *
             * -----------------------------------------------------------------------------------------
             */

            if (useSECs && codepoint < SEC_CHARS_LEN) {
                // We will try to use a SEC

                final char sec = SEC_CHARS[codepoint];

                // '\0' cannot be followed by a digit (they would be read together as an octal escape), so in
                // that case U+0000 is escaped as hexadecimal instead.
                if (sec != SEC_CHARS_NO_SEC &&
                        (codepoint != 0x00 || !isDigit((i + 1 < max) ? text.charAt(i + 1) : -1))) {
                    // SEC found! just write it and go for the next char
                    strBuilder.append(ESCAPE_PREFIX);
                    strBuilder.append(sec);
                    continue;
                }

            }

            /*
             * No SEC-escape was possible, so we need xhexa/uhexa escape.
             */

            if (useXHexa && codepoint <= 0xFF) {
                // Codepoint is <= 0xFF, so we can use XHEXA escapes
                strBuilder.append(ESCAPE_XHEXA_PREFIX);
                strBuilder.append(toXHexa(codepoint));
                continue;
            }

            if (Character.charCount(codepoint) > 1) {
                final char[] codepointChars = Character.toChars(codepoint);
                strBuilder.append(ESCAPE_UHEXA_PREFIX);
                strBuilder.append(toUHexa(codepointChars[0]));
                strBuilder.append(ESCAPE_UHEXA_PREFIX);
                strBuilder.append(toUHexa(codepointChars[1]));
                continue;
            }

            strBuilder.append(ESCAPE_UHEXA_PREFIX);
            strBuilder.append(toUHexa(codepoint));

        }


        /*
         * -----------------------------------------------------------------------------------------------
         * Final cleaning: return the original String object if no escape was actually needed. Otherwise
         *                 append the remaining unescaped text to the string builder and return.
         * -----------------------------------------------------------------------------------------------
         */

        if (strBuilder == null) {
            return text;
        }

        if (max - readOffset > 0) {
            strBuilder.append(text, readOffset, max);
        }

        return strBuilder.toString();

    }




    /*
     * Perform an escape operation, based on a Reader, according to the specified level and type and writing the
     * result to a Writer.
     *
     * Note this reader is going to be read char-by-char, so some kind of buffering might be appropriate if this
     * is an inconvenience for the specific Reader implementation.
     */
    static void escape(
            final Reader reader, final Writer writer, final JavaScriptEscapeType escapeType, final JavaScriptEscapeLevel escapeLevel)
            throws IOException {

        if (reader == null) {
            return;
        }

        final int level = escapeLevel.getEscapeLevel();
        final boolean useSECs = escapeType.getUseSECs();
        final boolean useXHexa = escapeType.getUseXHexa();

        int c0, c1, c2; // c0: last char, c1: current char, c2: next char

        c1 = -1;
        c2 = reader.read();

        while (c2 >= 0) {

            c0 = c1;
            c1 = c2;
            c2 = reader.read();

            final int codepoint = codePointAt((char)c1, (char)c2);


            /*
             * Shortcut: most characters will be ASCII/Alphanumeric, and we won't need to do anything at
             * all for them
             */
            if (codepoint <= (ESCAPE_LEVELS_LEN - 2) && level < ESCAPE_LEVELS[codepoint]) {
                writer.write(c1);
                continue;
            }

            /*
             * Check whether the character is a slash (solidus). In such case, only escape if it
             * appears after a '<' ('</') or level >= 3 (non alphanumeric)
             */
            if (codepoint == '/' && level < 3 && c0 != '<') {
                writer.write(c1);
                continue;
            }

            /*
             * Check whether the character is a dollar sign. In such case, only escape if it is followed by '{' (which
             * would start a substitution in a template literal), if it is the last char (as code right after the
             * escaped text might start with '{'), or if level >= 3 (non alphanumeric)
             */
            if (codepoint == '$' && level < 3 && c2 >= 0 && c2 != '{') {
                writer.write(c1);
                continue;
            }

            /*
             * Check whether the character is an opening curly bracket. In such case, only escape if it is the first
             * char (as code right before the escaped text might end with '$'), or if level >= 3 (non alphanumeric)
             */
            if (codepoint == '{' && level < 3 && c0 >= 0) {
                writer.write(c1);
                continue;
            }

            /*
             * Shortcut: we might not want to escape non-ASCII chars at all either.
             * We also check we are not dealing with U+2028 or U+2029, which the JavaScript spec considers
             * LineTerminators and therefore should be escaped always.
             */
            if (codepoint > (ESCAPE_LEVELS_LEN - 2) && level < ESCAPE_LEVELS[ESCAPE_LEVELS_LEN - 1] &&
                    codepoint != '\u2028' && codepoint != '\u2029') {

                writer.write(c1);

                if (Character.charCount(codepoint) > 1) {
                    // This is to compensate that we are actually escaping two char[] positions with a single codepoint.

                    writer.write(c2);

                    c0 = c1;
                    c1 = c2;
                    c2 = reader.read();

                }

                continue;

            }


            /*
             * We know we need to escape, so from here on we will only work with the codepoint -- we can advance
             * the chars.
             */

            if (Character.charCount(codepoint) > 1) {
                // This is to compensate that we are actually reading two char positions with a single codepoint.
                c0 = c1;
                c1 = c2;
                c2 = reader.read();
            }


            /*
             * -----------------------------------------------------------------------------------------
             *
             * Perform the real escape, attending the different combinations of SECs, XHEXA and UHEXA
             *
             * -----------------------------------------------------------------------------------------
             */

            if (useSECs && codepoint < SEC_CHARS_LEN) {
                // We will try to use a SEC

                final char sec = SEC_CHARS[codepoint];

                // '\0' cannot be followed by a digit (they would be read together as an octal escape), so in
                // that case U+0000 is escaped as hexadecimal instead.
                if (sec != SEC_CHARS_NO_SEC && (codepoint != 0x00 || !isDigit(c2))) {
                    // SEC found! just write it and go for the next char
                    writer.write(ESCAPE_PREFIX);
                    writer.write(sec);
                    continue;
                }

            }

            /*
             * No SEC-escape was possible, so we need xhexa/uhexa escape.
             */

            if (useXHexa && codepoint <= 0xFF) {
                // Codepoint is <= 0xFF, so we can use XHEXA escapes
                writer.write(ESCAPE_XHEXA_PREFIX);
                writer.write(toXHexa(codepoint));
                continue;
            }

            if (Character.charCount(codepoint) > 1) {
                final char[] codepointChars = Character.toChars(codepoint);
                writer.write(ESCAPE_UHEXA_PREFIX);
                writer.write(toUHexa(codepointChars[0]));
                writer.write(ESCAPE_UHEXA_PREFIX);
                writer.write(toUHexa(codepointChars[1]));
                continue;
            }

            writer.write(ESCAPE_UHEXA_PREFIX);
            writer.write(toUHexa(codepoint));

        }

    }




    /*
     * Perform an escape operation, based on char[], according to the specified level and type.
     */
    static void escape(final char[] text, final int offset, final int len, final Writer writer,
                       final JavaScriptEscapeType escapeType, final JavaScriptEscapeLevel escapeLevel)
                       throws IOException {

        if (text == null || text.length == 0) {
            return;
        }

        final int level = escapeLevel.getEscapeLevel();
        final boolean useSECs = escapeType.getUseSECs();
        final boolean useXHexa = escapeType.getUseXHexa();

        final int max = (offset + len);

        int readOffset = offset;

        for (int i = offset; i < max; i++) {

            final int codepoint = Character.codePointAt(text, i);


            /*
             * Shortcut: most characters will be ASCII/Alphanumeric, and we won't need to do anything at
             * all for them
             */
            if (codepoint <= (ESCAPE_LEVELS_LEN - 2) && level < ESCAPE_LEVELS[codepoint]) {
                continue;
            }

            /*
             * Check whether the character is a slash (solidus). In such case, only escape if it
             * appears after a '<' ('</') or level >= 3 (non alphanumeric)
             */
            if (codepoint == '/' && level < 3 && (i == 0 || text[i - 1] != '<')) {
                continue;
            }

            /*
             * Check whether the character is a dollar sign. In such case, only escape if it is followed by '{' (which
             * would start a substitution in a template literal), if it is the last char (as code right after the
             * escaped text might start with '{'), or if level >= 3 (non alphanumeric)
             */
            if (codepoint == '$' && level < 3 && (i + 1) < max && text[i + 1] != '{') {
                continue;
            }

            /*
             * Check whether the character is an opening curly bracket. In such case, only escape if it is the first
             * char (as code right before the escaped text might end with '$'), or if level >= 3 (non alphanumeric)
             */
            if (codepoint == '{' && level < 3 && i > offset) {
                continue;
            }

            /*
             * Shortcut: we might not want to escape non-ASCII chars at all either.
             * We also check we are not dealing with U+2028 or U+2029, which the JavaScript spec considers
             * LineTerminators and therefore should be escaped always.
             */
            if (codepoint > (ESCAPE_LEVELS_LEN - 2) && level < ESCAPE_LEVELS[ESCAPE_LEVELS_LEN - 1] &&
                    codepoint != '\u2028' && codepoint != '\u2029') {

                if (Character.charCount(codepoint) > 1) {
                    // This is to compensate that we are actually escaping two char[] positions with a single codepoint.
                    i++;
                }

                continue;

            }


            /*
             * At this point we know for sure we will need some kind of escape, so we
             * can write all the contents pending up to this point.
             */

            if (i - readOffset > 0) {
                writer.write(text, readOffset, (i - readOffset));
            }

            if (Character.charCount(codepoint) > 1) {
                // This is to compensate that we are actually reading two char[] positions with a single codepoint.
                i++;
            }

            readOffset = i + 1;


            /*
             * -----------------------------------------------------------------------------------------
             *
             * Perform the real escape, attending the different combinations of SECs, XHEXA and UHEXA
             *
             * -----------------------------------------------------------------------------------------
             */

            if (useSECs && codepoint < SEC_CHARS_LEN) {
                // We will try to use a SEC

                final char sec = SEC_CHARS[codepoint];

                // '\0' cannot be followed by a digit (they would be read together as an octal escape), so in
                // that case U+0000 is escaped as hexadecimal instead.
                if (sec != SEC_CHARS_NO_SEC &&
                        (codepoint != 0x00 || !isDigit((i + 1 < max) ? text[i + 1] : -1))) {
                    // SEC found! just write it and go for the next char
                    writer.write(ESCAPE_PREFIX);
                    writer.write(sec);
                    continue;
                }

            }

            /*
             * No SEC-escape was possible, so we need xhexa/uhexa escape.
             */

            if (useXHexa && codepoint <= 0xFF) {
                // Codepoint is <= 0xFF, so we can use XHEXA escapes
                writer.write(ESCAPE_XHEXA_PREFIX);
                writer.write(toXHexa(codepoint));
                continue;
            }

            if (Character.charCount(codepoint) > 1) {
                final char[] codepointChars = Character.toChars(codepoint);
                writer.write(ESCAPE_UHEXA_PREFIX);
                writer.write(toUHexa(codepointChars[0]));
                writer.write(ESCAPE_UHEXA_PREFIX);
                writer.write(toUHexa(codepointChars[1]));
                continue;
            }

            writer.write(ESCAPE_UHEXA_PREFIX);
            writer.write(toUHexa(codepoint));

        }


        /*
         * -----------------------------------------------------------------------------------------------
         * Final cleaning: return the original String object if no escape was actually needed. Otherwise
         *                 append the remaining unescaped text to the string builder and return.
         * -----------------------------------------------------------------------------------------------
         */

        if (max - readOffset > 0) {
            writer.write(text, readOffset, (max - readOffset));
        }

    }








    /*
     * Computes the numeric value (0..15) of a hexadecimal-digit char (0-9, A-F, a-f), returning -1 for any
     * other char. Used by the parseIntFromReference methods below.
     */
    private static int hexaValue(final char c) {
        if (c >= '0' && c <= '9') {
            return (int) c - (int) '0';
        }
        if (c >= 'A' && c <= 'F') {
            return (int) c - (int) 'A' + 10;
        }
        if (c >= 'a' && c <= 'f') {
            return (int) c - (int) 'a' + 10;
        }
        return -1;
    }


    /*
     * These methods (the three versions) are used instead of Integer.parseInt(str,radix) in order to avoid the need
     * to create substrings of the text being unescaped to feed such method.
     * -  No need to check all chars are within the radix limits - reference parsing code will already have done so.
     */

    static int parseIntFromReference(final String text, final int start, final int end, final int radix) {
        int result = 0;
        for (int i = start; i < end; i++) {
            final char c = text.charAt(i);
            result = (radix * result) + hexaValue(c);
        }
        return result;
    }

    static int parseIntFromReference(final char[] text, final int start, final int end, final int radix) {
        int result = 0;
        for (int i = start; i < end; i++) {
            final char c = text[i];
            result = (radix * result) + hexaValue(c);
        }
        return result;
    }





    static boolean isOctalEscape(final String text, final int start, final int end) {

        if (start >= end) {
            return false;
        }

        final char c1 = text.charAt(start);
        if (c1 < '0' || c1 > '7') {
            return false;
        }

        if (c1 != '0') {
            return true;
        }

        // A '0' followed by more octal digits is an octal escape (so \00 and \000 are a single U+0000).
        // If it is not, this is the U+0000 escape sequence on its own.
        if (start + 1 >= end) {
            return false;
        }
        final char c2 = text.charAt(start + 1);
        return (c2 >= '0' && c2 <= '7');

    }


    static boolean isOctalEscape(final char[] text, final int start, final int end) {

        if (start >= end) {
            return false;
        }

        final char c1 = text[start];
        if (c1 < '0' || c1 > '7') {
            return false;
        }

        if (c1 != '0') {
            return true;
        }

        // A '0' followed by more octal digits is an octal escape (so \00 and \000 are a single U+0000).
        // If it is not, this is the U+0000 escape sequence on its own.
        if (start + 1 >= end) {
            return false;
        }
        final char c2 = text[start + 1];
        return (c2 >= '0' && c2 <= '7');

    }




    /*
     * Perform an unescape operation based on String.
     */
    static String unescape(final String text) {

        if (text == null) {
            return null;
        }

        StringBuilder strBuilder = null;

        final int offset = 0;
        final int max = text.length();

        int readOffset = offset;
        int referenceOffset = offset;

        for (int i = offset; i < max; i++) {

            final char c = text.charAt(i);

            /*
             * Check the need for an unescape operation at this point
             */

            if (c != ESCAPE_PREFIX || (i + 1) >= max) {
                continue;
            }

            int codepoint = -1;

            if (c == ESCAPE_PREFIX) {

                final char c1 = text.charAt(i + 1);

                switch (c1) {
                    case '0': if (!isOctalEscape(text,i + 1,max)) { codepoint = 0x00; referenceOffset = i + 1; }; break;
                    case 'b': codepoint = 0x08; referenceOffset = i + 1; break;
                    case 't': codepoint = 0x09; referenceOffset = i + 1; break;
                    case 'n': codepoint = 0x0A; referenceOffset = i + 1; break;
                    case 'v': codepoint = 0x0B; referenceOffset = i + 1; break;
                    case 'f': codepoint = 0x0C; referenceOffset = i + 1; break;
                    case 'r': codepoint = 0x0D; referenceOffset = i + 1; break;
                    case '"': codepoint = 0x22; referenceOffset = i + 1; break;
                    case '\'': codepoint = 0x27; referenceOffset = i + 1; break;
                    case '\\': codepoint = 0x5C; referenceOffset = i + 1; break;
                    case '/': codepoint = 0x2F; referenceOffset = i + 1; break;
                    // line terminators (LF, CR, LS, PS). When escaped, these are line continuators
                    case '\n':
                    case '\u2028':
                    case '\u2029': codepoint = -2; referenceOffset = i + 1; break;
                    // carriage return, which may be followed by a line feed (CR LF is a single line terminator)
                    case '\r':
                        codepoint = -2;
                        referenceOffset = ((i + 2) < max && text.charAt(i + 2) == '\n') ? (i + 2) : (i + 1);
                        break;
                }

                if (codepoint == -1) {

                    if (c1 == ESCAPE_XHEXA_PREFIX2) {
                        // This can be a xhexa escape, we need exactly two more characters

                        int f = i + 2;
                        while (f < (i + 4) && f < max) {
                            final char cf = text.charAt(f);
                            if (!((cf >= '0' && cf <= '9') || (cf >= 'A' && cf <= 'F') || (cf >= 'a' && cf <= 'f'))) {
                                break;
                            }
                            f++;
                        }

                        if ((f - (i + 2)) < 2) {
                            // We weren't able to consume the required two hexa chars, leave it as slash+'x', which
                            // is invalid, and let the corresponding JavaScript engine fail.
                            i++;
                            continue;
                        }

                        codepoint = parseIntFromReference(text, i + 2, f, 16);

                        // Fast-forward to the first char after the parsed codepoint
                        referenceOffset = f - 1;

                        // Don't continue here, just let the unescape code below do its job

                    } else if (c1 == ESCAPE_UHEXA_PREFIX2) {
                        // This can be a uhexa escape, we need exactly four more characters

                        int f = i + 2;
                        while (f < (i + 6) && f < max) {
                            final char cf = text.charAt(f);
                            if (!((cf >= '0' && cf <= '9') || (cf >= 'A' && cf <= 'F') || (cf >= 'a' && cf <= 'f'))) {
                                break;
                            }
                            f++;
                        }

                        if ((f - (i + 2)) < 4) {
                            // We weren't able to consume the required four hexa chars, leave it as slash+'u', which
                            // is invalid, and let the corresponding JavaScript engine fail.
                            i++;
                            continue;
                        }

                        codepoint = parseIntFromReference(text, i + 2, f, 16);

                        // Fast-forward to the first char after the parsed codepoint
                        referenceOffset = f - 1;

                        // Don't continue here, just let the unescape code below do its job

                    } else if (c1 >= '0' && c1 <= '7') {
                        // This can be a octal escape, we need at least 1 more char, and up to 3 more.

                        int f = i + 2;
                        while (f < (i + 4) && f < max) { // We need only a max of two more chars
                            final char cf = text.charAt(f);
                            if (!(cf >= '0' && cf <= '7')) {
                                break;
                            }
                            f++;
                        }

                        codepoint = parseIntFromReference(text, i + 1, f, 8);

                        if (codepoint > 0xFF) {
                            // Maximum octal escape char is FF. Ignore the last digit
                            codepoint = parseIntFromReference(text, i + 1, f - 1, 8);
                            referenceOffset = f - 2;
                        } else {
                            referenceOffset = f - 1;
                        }

                        // Don't continue here, just let the unescape code below do its job

                    } else {

                        // We weren't able to consume any valid escape chars, just consider it a normal char,
                        // which is allowed by the JavaScript specification (NonEscapeCharacter). This includes
                        // '8' and '9', which are not octal digits.

                        codepoint = (int) c1;
                        referenceOffset = i + 1;

                    }

                }

            }


            /*
             * At this point we know for sure we will need some kind of unescape, so we
             * can increase the offset and initialize the string builder if needed, along with
             * copying to it all the contents pending up to this point.
             */

            if (strBuilder == null) {
                strBuilder = new StringBuilder(max + 5);
            }

            if (i - readOffset > 0) {
                strBuilder.append(text, readOffset, i);
            }

            i = referenceOffset;
            readOffset = i + 1;

            /*
             * --------------------------
             *
             * Perform the real unescape
             *
             * --------------------------
             */

            if (codepoint > '\uFFFF') {
                strBuilder.append(Character.toChars(codepoint));
            } else if (codepoint != -2){ // We use -2 to signal the line continuator, which should be ignored in output
                strBuilder.append((char)codepoint);
            }

        }


        /*
         * -----------------------------------------------------------------------------------------------
         * Final cleaning: return the original String object if no unescape was actually needed. Otherwise
         *                 append the remaining escaped text to the string builder and return.
         * -----------------------------------------------------------------------------------------------
         */

        if (strBuilder == null) {
            return text;
        }

        if (max - readOffset > 0) {
            strBuilder.append(text, readOffset, max);
        }

        return strBuilder.toString();

    }






    /*
     * Perform an unescape operation based on a Reader, writing the results to a Writer.
     *
     * Note this reader is going to be read char-by-char, so some kind of buffering might be appropriate if this
     * is an inconvenience for the specific Reader implementation.
     */
    static void unescape(final Reader reader, final Writer writer) throws IOException {

        if (reader == null) {
            return;
        }

        int escapei = 0;
        final char[] escapes = new char[4];
        int c1, c2, ce; // c1: current char, c2: next char, ce: current escape char

        c2 = reader.read();

        while (c2 >= 0) {

            c1 = c2;
            c2 = reader.read();

            escapei = 0;

            /*
             * Check the need for an unescape operation at this point
             */

            if (c1 != ESCAPE_PREFIX || c2 < 0) {
                writer.write(c1);
                continue;
            }

            int codepoint = -1;

            if (c1 == ESCAPE_PREFIX) {

                switch (c2) {
                    case 'b': codepoint = 0x08; c1 = c2; c2 = reader.read(); break;
                    case 't': codepoint = 0x09; c1 = c2; c2 = reader.read(); break;
                    case 'n': codepoint = 0x0A; c1 = c2; c2 = reader.read(); break;
                    case 'v': codepoint = 0x0B; c1 = c2; c2 = reader.read(); break;
                    case 'f': codepoint = 0x0C; c1 = c2; c2 = reader.read(); break;
                    case 'r': codepoint = 0x0D; c1 = c2; c2 = reader.read(); break;
                    case '"': codepoint = 0x22; c1 = c2; c2 = reader.read(); break;
                    case '\'': codepoint = 0x27; c1 = c2; c2 = reader.read(); break;
                    case '\\': codepoint = 0x5C; c1 = c2; c2 = reader.read(); break;
                    case '/': codepoint = 0x2F; c1 = c2; c2 = reader.read(); break;
                    // line terminators (LF, CR, LS, PS). When escaped, these are line continuators
                    case '\n':
                    case '\u2028':
                    case '\u2029': codepoint = -2; c1 = c2; c2 = reader.read(); break;
                    // carriage return, which may be followed by a line feed (CR LF is a single line terminator)
                    case '\r':
                        codepoint = -2;
                        c1 = c2;
                        c2 = reader.read();
                        if (c2 == '\n') {
                            c1 = c2;
                            c2 = reader.read();
                        }
                        break;
                }

                if (codepoint == -1) {

                    if (c2 == ESCAPE_XHEXA_PREFIX2) {
                        // This can be a xhexa escape, we need exactly two more characters

                        escapei = 0;
                        ce = reader.read();
                        while (ce >= 0 && escapei < 2) {
                            if (!((ce >= '0' && ce <= '9') || (ce >= 'A' && ce <= 'F') || (ce >= 'a' && ce <= 'f'))) {
                                break;
                            }
                            escapes[escapei] = (char) ce;
                            ce = reader.read();
                            escapei++;
                        }

                        if (escapei < 2) {
                            // We weren't able to consume the required four hexa chars, leave it as slash+'u', which
                            // is invalid, and let the corresponding JavaScript parser fail.
                            writer.write(c1);
                            writer.write(c2);
                            for (int i = 0; i < escapei; i++) {
                                c1 = c2;
                                c2 = escapes[i];
                                writer.write(c2);
                            }
                            c1 = c2;
                            c2 = ce;
                            continue;
                        }

                        c1 = escapes[3];
                        c2 = ce;

                        codepoint = parseIntFromReference(escapes, 0, 2, 16);

                        escapei = 0;

                        // Don't continue here, just let the unescape code below do its job

                    } else if (c2 == ESCAPE_UHEXA_PREFIX2) {
                        // This can be a uhexa escape, we need exactly four more characters

                        escapei = 0;
                        ce = reader.read();
                        while (ce >= 0 && escapei < 4) {
                            if (!((ce >= '0' && ce <= '9') || (ce >= 'A' && ce <= 'F') || (ce >= 'a' && ce <= 'f'))) {
                                break;
                            }
                            escapes[escapei] = (char) ce;
                            ce = reader.read();
                            escapei++;
                        }

                        if (escapei < 4) {
                            // We weren't able to consume the required four hexa chars, leave it as slash+'u', which
                            // is invalid, and let the corresponding JavaScript parser fail.
                            writer.write(c1);
                            writer.write(c2);
                            for (int i = 0; i < escapei; i++) {
                                c1 = c2;
                                c2 = escapes[i];
                                writer.write(c2);
                            }
                            c1 = c2;
                            c2 = ce;
                            continue;
                        }

                        c1 = escapes[3];
                        c2 = ce;

                        codepoint = parseIntFromReference(escapes, 0, 4, 16);

                        escapei = 0;

                        // Don't continue here, just let the unescape code below do its job

                    } else if (c2 >= '0' && c2 <= '7') {
                        // This can be a octal escape, we need at least 1 more char, and up to 3 more.

                        escapei = 0;
                        ce = c2;
                        while (ce >= 0 && escapei < 3) {
                            if (!(ce >= '0' && ce <= '7')) {
                                break;
                            }
                            escapes[escapei] = (char) ce;
                            ce = reader.read();
                            escapei++;
                        }

                        c1 = escapes[escapei - 1];
                        c2 = ce;

                        codepoint = parseIntFromReference(escapes, 0, escapei, 8);

                        if (codepoint > 0xFF) {
                            // Maximum octal escape char is FF. Ignore the last digit
                            codepoint = parseIntFromReference(escapes, 0, escapei - 1, 8);
                            System.arraycopy(escapes, escapei - 2, escapes, 0, 1);
                            escapei = 1;
                        } else {
                            escapei = 0;
                        }

                        // Don't continue here, just let the unescape code below do its job

                    } else {

                        // We weren't able to consume any valid escape chars, just consider it a normal char,
                        // which is allowed by the JavaScript specification (NonEscapeCharacter). This includes
                        // '8' and '9', which are not octal digits.

                        codepoint = c2;

                        c1 = c2;
                        c2 = reader.read();

                        escapei = 0;

                    }

                }

            }

            /*
             * --------------------------
             *
             * Perform the real unescape
             *
             * --------------------------
             */

            if (codepoint > '\uFFFF') {
                writer.write(Character.toChars(codepoint));
            } else if (codepoint != -2){ // We use -2 to signal the line continuator, which should be ignored in output
                writer.write((char)codepoint);
            }

            /*
             * ----------------------------------------
             * Cleanup, in case we had a partial match
             * ----------------------------------------
             */

            if (escapei > 0) {
                writer.write(escapes, 0, escapei);
                escapei = 0;
            }

        }

    }






    /*
     * Perform an unescape operation based on char[].
     */
    static void unescape(final char[] text, final int offset, final int len, final Writer writer)
                         throws IOException {

        if (text == null) {
            return;
        }

        final int max = (offset + len);

        int readOffset = offset;
        int referenceOffset = offset;

        for (int i = offset; i < max; i++) {

            final char c = text[i];

            /*
             * Check the need for an unescape operation at this point
             */

            if (c != ESCAPE_PREFIX || (i + 1) >= max) {
                continue;
            }

            int codepoint = -1;

            if (c == ESCAPE_PREFIX) {

                final char c1 = text[i + 1];

                switch (c1) {
                    case '0': if (!isOctalEscape(text,i + 1,max)) { codepoint = 0x00; referenceOffset = i + 1; }; break;
                    case 'b': codepoint = 0x08; referenceOffset = i + 1; break;
                    case 't': codepoint = 0x09; referenceOffset = i + 1; break;
                    case 'n': codepoint = 0x0A; referenceOffset = i + 1; break;
                    case 'v': codepoint = 0x0B; referenceOffset = i + 1; break;
                    case 'f': codepoint = 0x0C; referenceOffset = i + 1; break;
                    case 'r': codepoint = 0x0D; referenceOffset = i + 1; break;
                    case '"': codepoint = 0x22; referenceOffset = i + 1; break;
                    case '\'': codepoint = 0x27; referenceOffset = i + 1; break;
                    case '\\': codepoint = 0x5C; referenceOffset = i + 1; break;
                    case '/': codepoint = 0x2F; referenceOffset = i + 1; break;
                    // line terminators (LF, CR, LS, PS). When escaped, these are line continuators
                    case '\n':
                    case '\u2028':
                    case '\u2029': codepoint = -2; referenceOffset = i + 1; break;
                    // carriage return, which may be followed by a line feed (CR LF is a single line terminator)
                    case '\r':
                        codepoint = -2;
                        referenceOffset = ((i + 2) < max && text[i + 2] == '\n') ? (i + 2) : (i + 1);
                        break;
                }

                if (codepoint == -1) {

                    if (c1 == ESCAPE_XHEXA_PREFIX2) {
                        // This can be a xhexa escape, we need exactly two more characters

                        int f = i + 2;
                        while (f < (i + 4) && f < max) {
                            final char cf = text[f];
                            if (!((cf >= '0' && cf <= '9') || (cf >= 'A' && cf <= 'F') || (cf >= 'a' && cf <= 'f'))) {
                                break;
                            }
                            f++;
                        }

                        if ((f - (i + 2)) < 2) {
                            // We weren't able to consume the required two hexa chars, leave it as slash+'x', which
                            // is invalid, and let the corresponding JavaScript engine fail.
                            i++;
                            continue;
                        }

                        codepoint = parseIntFromReference(text, i + 2, f, 16);

                        // Fast-forward to the first char after the parsed codepoint
                        referenceOffset = f - 1;

                        // Don't continue here, just let the unescape code below do its job

                    } else if (c1 == ESCAPE_UHEXA_PREFIX2) {
                        // This can be a uhexa escape, we need exactly four more characters

                        int f = i + 2;
                        while (f < (i + 6) && f < max) {
                            final char cf = text[f];
                            if (!((cf >= '0' && cf <= '9') || (cf >= 'A' && cf <= 'F') || (cf >= 'a' && cf <= 'f'))) {
                                break;
                            }
                            f++;
                        }

                        if ((f - (i + 2)) < 4) {
                            // We weren't able to consume the required four hexa chars, leave it as slash+'u', which
                            // is invalid, and let the corresponding JavaScript engine fail.
                            i++;
                            continue;
                        }

                        codepoint = parseIntFromReference(text, i + 2, f, 16);

                        // Fast-forward to the first char after the parsed codepoint
                        referenceOffset = f - 1;

                        // Don't continue here, just let the unescape code below do its job

                    } else if (c1 >= '0' && c1 <= '7') {
                        // This can be a octal escape, we need at least 1 more char, and up to 3 more.

                        int f = i + 2;
                        while (f < (i + 4) && f < max) { // We need only a max of two more chars
                            final char cf = text[f];
                            if (!(cf >= '0' && cf <= '7')) {
                                break;
                            }
                            f++;
                        }

                        codepoint = parseIntFromReference(text, i + 1, f, 8);
                        if (codepoint > 0xFF) {
                            // Maximum octal escape char is FF. Ignore the last digit
                            codepoint = parseIntFromReference(text, i + 1, f - 1, 8);
                            referenceOffset = f - 2;
                        } else {
                            referenceOffset = f - 1;
                        }

                        // Don't continue here, just let the unescape code below do its job

                    } else {

                        // We weren't able to consume any valid escape chars, just consider it a normal char,
                        // which is allowed by the JavaScript specification (NonEscapeCharacter). This includes
                        // '8' and '9', which are not octal digits.

                        codepoint = (int) c1;
                        referenceOffset = i + 1;

                    }

                }

            }


            /*
             * At this point we know for sure we will need some kind of unescape, so we
             * write all the contents pending up to this point.
             */

            if (i - readOffset > 0) {
                writer.write(text, readOffset, (i - readOffset));
            }

            i = referenceOffset;
            readOffset = i + 1;

            /*
             * --------------------------
             *
             * Perform the real unescape
             *
             * --------------------------
             */

            if (codepoint > '\uFFFF') {
                writer.write(Character.toChars(codepoint));
            } else if (codepoint != -2){ // We use -2 to signal the line continuator, which should be ignored in output
                writer.write((char)codepoint);
            }

        }


        /*
         * -----------------------------------------------------------------------------------------------
         * Final cleaning: writer the remaining escaped text and return.
         * -----------------------------------------------------------------------------------------------
         */

        if (max - readOffset > 0) {
            writer.write(text, readOffset, (max - readOffset));
        }

    }




    private static int codePointAt(final char c1, final char c2) {
        if (Character.isHighSurrogate(c1)) {
            if (c2 >= 0) {
                if (Character.isLowSurrogate(c2)) {
                    return Character.toCodePoint(c1, c2);
                }
            }
        }
        return c1;
    }



}

